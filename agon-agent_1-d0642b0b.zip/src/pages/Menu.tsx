import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Sparkles } from 'lucide-react';
import type { Category, MenuItem } from '../lib/api';
import { getCategories, getMenuItems } from '../lib/api';
import GlassCard from '../components/GlassCard';
import MenuTabs from '../components/MenuTabs';
import MenuItemCard from '../components/MenuItemCard';
import AddToCartBurst from '../components/AddToCartBurst';

export default function Menu() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [active, setActive] = useState<number | null>(null);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  const [burst, setBurst] = useState<{ show: boolean; x: number; y: number }>({ show: false, x: 0, y: 0 });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [cats, menu] = await Promise.all([getCategories(), getMenuItems()]);
      setCategories(cats);
      setItems(menu);
      setActive(cats[0]?.id ?? null);
    } catch (err) {
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filtered = useMemo(() => {
    let list = items;
    if (active) list = list.filter((i) => i.category_id === active);
    if (q.trim()) {
      const qq = q.trim().toLowerCase();
      list = list.filter((i) => i.name.toLowerCase().includes(qq) || i.description.toLowerCase().includes(qq));
    }
    return list;
  }, [items, active, q]);

  const onBurst = (x: number, y: number) => {
    setBurst({ show: true, x, y });
    window.setTimeout(() => setBurst((b) => ({ ...b, show: false })), 240);
  };

  return (
    <div className="pt-24">
      <AddToCartBurst show={burst.show} x={burst.x} y={burst.y} />

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-end">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-white/70">
              <Sparkles className="h-4 w-4 text-[#d6b25e]" />
              Premium Menu
            </div>
            <h1 className="mt-4 text-4xl sm:text-5xl font-semibold text-white">Order-worthy. Camera-ready.</h1>
            <p className="mt-3 text-sm text-white/60 max-w-xl">
              Browse by category, fine-tune quantity, and send your order on WhatsApp in seconds.
            </p>
          </div>

          <GlassCard className="p-3">
            <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-3">
              <Search className="h-4 w-4 text-[#d6b25e]" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search dishes, drinks, desserts…"
                className="w-full bg-transparent text-sm text-white/90 placeholder:text-white/35 outline-none"
              />
            </div>
          </GlassCard>
        </div>

        <div className="mt-8">
          {loading ? (
            <GlassCard className="p-6">
              <div className="h-5 w-52 rounded bg-white/10" />
              <div className="mt-4 h-10 w-full rounded-2xl bg-white/10" />
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {Array.from({ length: 6 }).map((_, k) => (
                  <div key={k} className="h-80 rounded-3xl bg-white/10" />
                ))}
              </div>
            </GlassCard>
          ) : (
            <>
              <MenuTabs categories={categories} activeId={active} onChange={setActive} />
              <motion.div
                key={`${active}-${q}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35 }}
                className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
              >
                {filtered.map((it) => (
                  <MenuItemCard key={it.id} item={it} onBurst={onBurst} />
                ))}
              </motion.div>
              {filtered.length === 0 && (
                <GlassCard className="mt-6 p-6">
                  <div className="text-white/70">No matches found.</div>
                  <div className="mt-2 text-sm text-white/50">Try a different keyword or category.</div>
                </GlassCard>
              )}
            </>
          )}
        </div>

        <div className="h-16" />
      </section>
    </div>
  );
}
