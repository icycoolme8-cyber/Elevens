import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2, MapPin, MessageCircleMore, Phone, Star, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useEffect, useMemo, useState } from 'react';
import GoldButton from '../components/GoldButton';
import GlassCard from '../components/GlassCard';
import FeaturedCarousel from '../components/FeaturedCarousel';
import ParallaxSection from '../components/ParallaxSection';
import type { InstagramPost, MenuItem, Testimonial } from '../lib/api';
import { getInstagramPosts, getMenuItems, getTestimonials } from '../lib/api';

const fadeUp = {
  hidden: { opacity: 0, y: 18 },
  visible: (d = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.7, delay: d } }),
};

export default function Home({
  brandName,
  whatsappPhone,
}: {
  brandName: string;
  whatsappPhone: string;
}) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [insta, setInsta] = useState<InstagramPost[]>([]);
  const [loading, setLoading] = useState(true);

  const featuredItems = useMemo(() => menuItems.filter((m) => m.is_featured), [menuItems]);

  const fetchAll = async () => {
    try {
      const [m, t, i] = await Promise.all([getMenuItems(), getTestimonials(), getInstagramPosts(6)]);
      setMenuItems(m);
      setTestimonials(t);
      setInsta(i);
    } catch (err) {
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative min-h-[92vh] overflow-hidden">
        <div className="absolute inset-0">
          <video
            className="h-full w-full object-cover"
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            poster="https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1600"
          >
            <source src="https://videos.pexels.com/video-files/853835/853835-hd_1920_1080_30fps.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-black/55" />
          <div className="absolute inset-0 bg-[radial-gradient(70%_55%_at_50%_20%,rgba(214,178,94,0.22),rgba(0,0,0,0)_60%)]" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/70 to-black" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid min-h-[92vh] items-center py-16">
            <div className="max-w-3xl">
              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/30 px-4 py-2 text-xs text-white/70 backdrop-blur-xl"
              >
                <span className="h-2 w-2 rounded-full bg-[#d6b25e]" />
                Late-night premium delivery • Crafted on demand
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.85, delay: 0.1 }}
                className="mt-6 text-5xl sm:text-6xl lg:text-7xl font-semibold tracking-tight text-white"
              >
                {brandName}
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.85, delay: 0.18 }}
                className="mt-4 text-lg sm:text-xl text-white/70"
              >
                <span className="text-[#d6b25e]">Elevate Your Taste</span>. Cinematic comfort food with luxury finish.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.85, delay: 0.26 }}
                className="mt-8 flex flex-col sm:flex-row gap-3"
              >
                <Link to="/menu">
                  <GoldButton size="lg">
                    View Menu <ArrowRight className="h-4 w-4" />
                  </GoldButton>
                </Link>
                <a
                  href={`https://wa.me/${(whatsappPhone || '').replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <GoldButton variant="ghost" size="lg">
                    <MessageCircleMore className="h-4 w-4 text-[#d6b25e]" /> Order on WhatsApp
                  </GoldButton>
                </a>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.85, delay: 0.32 }}
                className="mt-10 grid grid-cols-2 sm:grid-cols-3 gap-3"
              >
                {[{ k: 'Delivery', v: '20–30 mins' }, { k: 'Rating', v: '4.8/5' }, { k: 'Open', v: '12pm–1am' }].map(
                  (s) => (
                    <div
                      key={s.k}
                      className="rounded-3xl border border-white/10 bg-black/25 px-4 py-4 backdrop-blur-2xl"
                    >
                      <div className="text-xs text-white/50">{s.k}</div>
                      <div className="mt-1 text-sm font-semibold text-white">{s.v}</div>
                    </div>
                  )
                )}
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="relative py-16 sm:py-20">
        <div className="absolute inset-0 bg-[radial-gradient(55%_45%_at_80%_20%,rgba(214,178,94,0.15),rgba(0,0,0,0)_60%)]" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {loading ? (
            <GlassCard className="p-8">
              <div className="h-6 w-56 rounded bg-white/10" />
              <div className="mt-3 h-4 w-full max-w-xl rounded bg-white/10" />
              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div className="aspect-[16/11] rounded-3xl bg-white/10" />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {[0, 1, 2, 3].map((k) => (
                    <div key={k} className="aspect-[16/11] rounded-3xl bg-white/10" />
                  ))}
                </div>
              </div>
            </GlassCard>
          ) : (
            <FeaturedCarousel items={featuredItems.length ? featuredItems : menuItems} />
          )}
        </div>
      </section>

      {/* Why Choose */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="max-w-2xl"
          >
            <div className="text-xs tracking-[0.32em] text-[#d6b25e]">WHY ELEVENS</div>
            <h2 className="mt-3 text-3xl sm:text-4xl font-semibold text-white">Luxury comfort. Precision delivery.</h2>
            <p className="mt-3 text-sm text-white/60">
              Crafted with premium ingredients, plated for camera-ready indulgence, and delivered with a warm, secure seal.
            </p>
          </motion.div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              {
                title: 'Signature recipes',
                desc: 'Chef-driven, balanced profiles — umami-forward, never ordinary.',
              },
              {
                title: 'Cinematic presentation',
                desc: 'Designed to look as good as it tastes — from grill marks to garnish.',
              },
              {
                title: 'WhatsApp-first ordering',
                desc: 'Fast, personal confirmation. No payment friction. High conversion.',
              },
            ].map((c, i) => (
              <motion.div
                key={c.title}
                custom={i * 0.06}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.25 }}
              >
                <GlassCard className="p-6 h-full">
                  <div className="flex items-center gap-2 text-white">
                    <CheckCircle2 className="h-5 w-5 text-[#d6b25e]" />
                    <div className="font-semibold">{c.title}</div>
                  </div>
                  <div className="mt-3 text-sm text-white/60">{c.desc}</div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Parallax Banner */}
      <ParallaxSection className="py-16 sm:py-20" strength={55}>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <GlassCard className="relative overflow-hidden">
            <div className="absolute inset-0">
              <img
                src="https://images.pexels.com/photos/70497/pexels-photo-70497.jpeg?auto=compress&cs=tinysrgb&w=1600"
                alt="Atmosphere"
                className="h-full w-full object-cover opacity-40"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-black" />
            </div>
            <div className="relative p-8 sm:p-10">
              <div className="max-w-2xl">
                <div className="text-xs tracking-[0.32em] text-[#d6b25e]">ATMOSPHERE</div>
                <div className="mt-3 text-2xl sm:text-3xl font-semibold text-white">
                  A midnight lounge, in every bite.
                </div>
                <div className="mt-3 text-sm text-white/60">
                  Pair signature burgers, artisanal desserts, and cold-brew rituals — curated to feel elite.
                </div>
                <div className="mt-6">
                  <Link to="/menu">
                    <GoldButton>
                      Explore the Menu <ArrowRight className="h-4 w-4" />
                    </GoldButton>
                  </Link>
                </div>
              </div>
            </div>
          </GlassCard>
        </div>
      </ParallaxSection>

      {/* Testimonials */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="flex items-end justify-between gap-4"
          >
            <div>
              <div className="text-xs tracking-[0.32em] text-[#d6b25e]">TESTIMONIALS</div>
              <h2 className="mt-3 text-3xl sm:text-4xl font-semibold text-white">Loved by late-night foodies</h2>
            </div>
            <div className="hidden sm:block text-sm text-white/55">Real words. Real cravings.</div>
          </motion.div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-5">
            {(loading ? [] : testimonials).slice(0, 6).map((t, i) => (
              <motion.div
                key={t.id}
                custom={i * 0.06}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.2 }}
              >
                <GlassCard className="p-6 h-full">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">{t.name}</div>
                      <div className="text-xs text-white/50">{t.title}</div>
                    </div>
                    <div className="flex items-center gap-1 text-[#d6b25e]">
                      {Array.from({ length: 5 }).map((_, k) => (
                        <Star key={k} className={`h-4 w-4 ${k < t.rating ? 'fill-[#d6b25e]' : ''}`} />
                      ))}
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-white/60">“{t.quote}”</div>
                </GlassCard>
              </motion.div>
            ))}

            {loading && (
              <div className="md:col-span-3">
                <GlassCard className="p-8">
                  <div className="h-4 w-64 rounded bg-white/10" />
                  <div className="mt-3 h-4 w-full rounded bg-white/10" />
                  <div className="mt-2 h-4 w-5/6 rounded bg-white/10" />
                </GlassCard>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Instagram */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-4">
            <div>
              <div className="text-xs tracking-[0.32em] text-[#d6b25e]">INSTAGRAM</div>
              <h2 className="mt-3 text-3xl sm:text-4xl font-semibold text-white">A feed made for cravings</h2>
              <p className="mt-2 text-sm text-white/60">Preview of recent plates — click through to open posts.</p>
            </div>
            <a
              className="hidden sm:inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white/80 hover:bg-white/[0.07]"
              href="#"
              onClick={(e) => e.preventDefault()}
            >
              <Instagram className="h-4 w-4 text-[#d6b25e]" />
              Follow
            </a>
          </div>

          <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {(loading ? [] : insta).map((p) => (
              <a
                key={p.id}
                href={p.permalink}
                target="_blank"
                rel="noreferrer"
                className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04]"
              >
                <div className="aspect-square">
                  <img
                    src={p.image_url}
                    alt={p.caption || 'Instagram'}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="absolute bottom-3 left-3 right-3 text-xs text-white/70 opacity-0 transition-opacity group-hover:opacity-100 line-clamp-2">
                  {p.caption}
                </div>
              </a>
            ))}

            {loading &&
              Array.from({ length: 6 }).map((_, k) => (
                <div key={k} className="aspect-square rounded-3xl border border-white/10 bg-white/[0.04]">
                  <div className="h-full w-full animate-pulse bg-white/5" />
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <GlassCard className="overflow-hidden">
              <div className="p-6 sm:p-8">
                <div className="text-xs tracking-[0.32em] text-[#d6b25e]">CONTACT</div>
                <div className="mt-3 text-3xl font-semibold text-white">Visit the lounge</div>
                <div className="mt-2 text-sm text-white/60">
                  Elite ambience, warm service — and delivery that arrives like it’s plated.
                </div>

                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <a
                    className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-[#fff0c2] via-[#d6b25e] to-[#8d6f2b] px-4 py-3 text-sm font-semibold text-black"
                    href={`https://wa.me/${(whatsappPhone || '').replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <MessageCircleMore className="h-4 w-4" /> WhatsApp
                  </a>
                  <a
                    className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white/85 hover:bg-white/[0.07]"
                    href="tel:+919999999999"
                  >
                    <Phone className="h-4 w-4 text-[#d6b25e]" /> Call
                  </a>
                </div>

                <div className="mt-6 space-y-3 text-sm">
                  <div className="flex items-center gap-2 text-white/70">
                    <MapPin className="h-4 w-4 text-[#d6b25e]" />
                    11/11 Elevens Avenue, City Centre
                  </div>
                  <div className="text-white/55">Opening hours: 12:00 PM – 01:00 AM</div>
                  <div className="text-white/55">Delivery radius: 6–8 km (subject to availability)</div>
                </div>

                <div className="mt-8 text-xs text-white/45">
                  Trust signals: secure packaging • hygiene-first kitchen • fast confirmation
                </div>
              </div>
            </GlassCard>

            <GlassCard className="overflow-hidden">
              <iframe
                title="Google Maps"
                src="https://www.google.com/maps?q=Connaught%20Place%2C%20New%20Delhi&output=embed"
                className="h-[360px] w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </GlassCard>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="text-sm tracking-[0.32em] text-white/75">{brandName.toUpperCase()}</div>
              <div className="mt-1 text-xs text-white/45">© {new Date().getFullYear()} {brandName}. All rights reserved.</div>
            </div>
            <div className="text-xs text-white/45">
              Built for performance • Mobile-first • WhatsApp conversion flow
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
