import React, { createContext, useContext, useMemo, useState } from 'react';

export type CartItem = {
  id: number;
  name: string;
  unitPrice: number;
  imageUrl: string;
  qty: number;
};

type CartState = {
  open: boolean;
  items: CartItem[];
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  add: (item: Omit<CartItem, 'qty'>, qty?: number) => void;
  setQty: (id: number, qty: number) => void;
  remove: (id: number) => void;
  clear: () => void;
  subtotal: number;
  totalQty: number;
};

const CartCtx = createContext<CartState | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<CartItem[]>([]);

  const add: CartState['add'] = (item, qty = 1) => {
    setItems((prev) => {
      const existing = prev.find((p) => p.id === item.id);
      if (existing) {
        return prev.map((p) => (p.id === item.id ? { ...p, qty: p.qty + qty } : p));
      }
      return [...prev, { ...item, qty }];
    });
    setOpen(true);
  };

  const setQty: CartState['setQty'] = (id, qty) => {
    setItems((prev) => {
      if (qty <= 0) return prev.filter((p) => p.id !== id);
      return prev.map((p) => (p.id === id ? { ...p, qty } : p));
    });
  };

  const remove: CartState['remove'] = (id) => setItems((prev) => prev.filter((p) => p.id !== id));
  const clear: CartState['clear'] = () => setItems([]);

  const subtotal = useMemo(
    () => items.reduce((sum, it) => sum + it.unitPrice * it.qty, 0),
    [items]
  );
  const totalQty = useMemo(() => items.reduce((sum, it) => sum + it.qty, 0), [items]);

  const value: CartState = {
    open,
    items,
    openCart: () => setOpen(true),
    closeCart: () => setOpen(false),
    toggleCart: () => setOpen((v) => !v),
    add,
    setQty,
    remove,
    clear,
    subtotal,
    totalQty,
  };

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const ctx = useContext(CartCtx);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
