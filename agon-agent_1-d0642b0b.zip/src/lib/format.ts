export function formatINR(paiseOrRupee: number) {
  const value = Number.isFinite(paiseOrRupee) ? paiseOrRupee : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
}

export function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}
