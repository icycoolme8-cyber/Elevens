export async function calculateEta() {
  // Simulate a lightweight compute / network jitter for premium UX
  const delay = 600 + Math.round(Math.random() * 700);
  await new Promise((r) => setTimeout(r, delay));
  // Dynamic but bounded
  const min = 20 + Math.round(Math.random() * 5);
  const max = min + 10 + Math.round(Math.random() * 5);
  return { min, max };
}
