export type Category = {
  id: number;
  name: string;
  slug: string;
  sort_order: number;
};

export type MenuItem = {
  id: number;
  category_id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  is_featured: boolean;
  is_active: boolean;
  sort_order: number;
  spicy_level: number;
  is_veg: boolean;
};

export type Testimonial = {
  id: number;
  name: string;
  title: string;
  quote: string;
  rating: number;
  sort_order: number;
};

export type InstagramPost = {
  id: number;
  image_url: string;
  caption: string;
  permalink: string;
  posted_at: string;
};

export async function getSettings() {
  const res = await fetch('/api/site_settings');
  if (!res.ok) throw new Error('Failed to load settings');
  return (await res.json()) as Record<string, any>;
}

export async function getCategories() {
  const res = await fetch('/api/categories');
  if (!res.ok) throw new Error('Failed to load categories');
  return (await res.json()) as Category[];
}

export async function getMenuItems(params?: { categoryId?: number; q?: string }) {
  const sp = new URLSearchParams();
  if (params?.categoryId) sp.set('category_id', String(params.categoryId));
  if (params?.q) sp.set('q', params.q);
  const res = await fetch(`/api/menu_items${sp.toString() ? `?${sp.toString()}` : ''}`);
  if (!res.ok) throw new Error('Failed to load menu items');
  return (await res.json()) as MenuItem[];
}

export async function getTestimonials() {
  const res = await fetch('/api/testimonials');
  if (!res.ok) throw new Error('Failed to load testimonials');
  return (await res.json()) as Testimonial[];
}

export async function getInstagramPosts(limit = 6) {
  const res = await fetch(`/api/instagram_posts?limit=${limit}`);
  if (!res.ok) throw new Error('Failed to load instagram posts');
  return (await res.json()) as InstagramPost[];
}
