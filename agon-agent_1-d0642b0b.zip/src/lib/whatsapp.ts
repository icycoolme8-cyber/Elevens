import { formatINR } from './format';

export function buildWhatsAppMessage(params: {
  brandName: string;
  items: Array<{ name: string; qty: number; unitPrice: number }>;
  customer: { name: string; phone: string; address: string };
}) {
  const { brandName, items, customer } = params;
  const lines: string[] = [];
  lines.push(`Hello ${brandName},`);
  lines.push('');
  lines.push('I want to order:');
  lines.push('');

  const total = items.reduce((sum, it) => sum + it.qty * it.unitPrice, 0);

  for (const it of items) {
    const itemTotal = it.qty * it.unitPrice;
    lines.push(`• ${it.qty}x ${it.name} — ${formatINR(itemTotal)}`);
  }

  lines.push('');
  lines.push(`Total: ${formatINR(total)}`);
  lines.push('');
  lines.push(`Name: ${customer.name || ''}`);
  lines.push(`Phone: ${customer.phone || ''}`);
  lines.push(`Address: ${customer.address || ''}`);

  return lines.join('\n');
}

export function openWhatsApp(phoneE164: string, message: string) {
  const cleanPhone = (phoneE164 || '').replace(/\D/g, '');
  const encoded = encodeURIComponent(message);
  const url = cleanPhone
    ? `https://wa.me/${cleanPhone}?text=${encoded}`
    : `https://wa.me/?text=${encoded}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}
