import { motion } from 'framer-motion';
import { Flame, Leaf, Plus, Minus } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import type { MenuItem } from '../lib/api';
import { formatINR } from '../lib/format';
import { useCart } from '../lib/cart';
import GlassCard from './GlassCard';

export default function MenuItemCard({
  item,
  onBurst,
}: {
  item: MenuItem;
  onBurst: (x: number, y: number) => void;
}) {
  const cart = useCart();
  const cartLine = useMemo(() => cart.items.find((i) => i.id === item.id), [cart.items, item.id]);
  const qtyInCart = cartLine?.qty || 0;
  const [localQty, setLocalQty] = useState(1);

  const add = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    onBurst(rect.left + rect.width / 2, rect.top + rect.height / 2);
    cart.add({ id: item.id, name: item.name, unitPrice: item.price, imageUrl: item.image_url }, localQty);
    setLocalQty(1);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.45 }}
    >
      <GlassCard className="group overflow-hidden">
        <div className="relative">
          <div className="relative aspect-[16/11] overflow-hidden">
            <img
              src={item.image_url}
              alt={item.name}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent" />
          </div>

          <div className="absolute left-4 top-4 flex gap-2">
            {item.is_veg && (
              <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-black/40 px-2 py-1 text-xs text-white/70">
                <Leaf className="h-3.5 w-3.5 text-emerald-300" /> Veg
              </span>
            )}
            {item.spicy_level > 0 && (
              <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-black/40 px-2 py-1 text-xs text-white/70">
                <Flame className="h-3.5 w-3.5 text-orange-300" />
                {item.spicy_level}
              </span>
            )}
          </div>

          {qtyInCart > 0 && (
            <div className="absolute right-4 top-4 rounded-full bg-[#d6b25e] px-2.5 py-1 text-xs font-semibold text-black">
              In cart: {qtyInCart}
            </div>
          )}
        </div>

        <div className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-lg font-semibold text-white">{item.name}</div>
              <div className="mt-1 text-sm text-white/60 line-clamp-2">{item.description}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-[#d6b25e]">{formatINR(item.price)}</div>
              <div className="mt-1 text-xs text-white/40">incl. taxes</div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            <div className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-1">
              <button
                className="grid h-9 w-9 place-items-center rounded-xl text-white/80 hover:bg-white/[0.06]"
                onClick={() => setLocalQty((v) => Math.max(1, v - 1))}
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </button>
              <div className="min-w-8 text-center text-sm text-white/80">{localQty}</div>
              <button
                className="grid h-9 w-9 place-items-center rounded-xl text-white/80 hover:bg-white/[0.06]"
                onClick={() => setLocalQty((v) => v + 1)}
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <motion.button
              onClick={add}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-[#fff0c2] via-[#d6b25e] to-[#8d6f2b] px-4 py-2.5 text-sm font-semibold text-black shadow-[0_18px_60px_-22px_rgba(214,178,94,0.65)]"
            >
              <Plus className="h-4 w-4" /> Add
            </motion.button>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
}
