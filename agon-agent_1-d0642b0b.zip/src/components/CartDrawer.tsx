import { AnimatePresence, motion } from 'framer-motion';
import { Minus, Plus, Trash2, X, MessageCircleMore, Clock3 } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useCart } from '../lib/cart';
import { formatINR } from '../lib/format';
import GlassCard from './GlassCard';
import UserDetailsModal from './UserDetailsModal';
import { calculateEta } from '../lib/eta';

export default function CartDrawer({ brandName, whatsappPhone }: { brandName: string; whatsappPhone: string }) {
  const cart = useCart();
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [etaLoading, setEtaLoading] = useState(false);
  const [eta, setEta] = useState<{ min: number; max: number } | null>(null);

  const canCheckout = cart.items.length > 0;

  useEffect(() => {
    if (!cart.open) return;
    setEtaLoading(true);
    setEta(null);
    let alive = true;
    calculateEta()
      .then((v) => {
        if (!alive) return;
        setEta(v);
      })
      .catch(() => {})
      .finally(() => {
        if (!alive) return;
        setEtaLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [cart.open, cart.items.length]);

  const subtitle = useMemo(() => {
    if (etaLoading) return 'Calculating ETA…';
    if (eta) return `Estimated delivery: ${eta.min}–${eta.max} mins`;
    return 'Estimated delivery: —';
  }, [etaLoading, eta]);

  return (
    <>
      <AnimatePresence>
        {cart.open && (
          <>
            <motion.div
              className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={cart.closeCart}
            />
            <motion.aside
              className="fixed right-0 top-0 z-[80] h-full w-full max-w-md border-l border-white/10 bg-black/65 backdrop-blur-2xl"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 340, damping: 34 }}
              aria-label="Cart"
            >
              <div className="flex h-full flex-col">
                <div className="flex items-start justify-between p-5 border-b border-white/10">
                  <div>
                    <div className="text-lg font-semibold text-white">Your Order</div>
                    <div className="mt-1 inline-flex items-center gap-2 text-xs text-white/50">
                      <Clock3 className={`h-4 w-4 ${etaLoading ? 'animate-spin' : ''} text-[#d6b25e]`} />
                      {subtitle}
                    </div>
                  </div>
                  <button
                    className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
                    onClick={cart.closeCart}
                    aria-label="Close cart"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="flex-1 overflow-auto p-5">
                  {cart.items.length === 0 ? (
                    <GlassCard className="p-6">
                      <div className="text-white/70">Your cart is empty.</div>
                      <div className="mt-2 text-sm text-white/50">
                        Explore the menu and add a few premium picks.
                      </div>
                    </GlassCard>
                  ) : (
                    <div className="space-y-4">
                      {cart.items.map((it) => (
                        <GlassCard key={it.id} className="p-4">
                          <div className="flex gap-3">
                            <div className="h-16 w-16 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
                              <img src={it.imageUrl} alt={it.name} className="h-full w-full object-cover" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-sm font-semibold text-white">{it.name}</div>
                              <div className="mt-1 text-xs text-white/60">{formatINR(it.unitPrice)} each</div>

                              <div className="mt-3 flex items-center justify-between gap-2">
                                <div className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-1">
                                  <button
                                    className="grid h-9 w-9 place-items-center rounded-xl text-white/80 hover:bg-white/[0.06]"
                                    onClick={() => cart.setQty(it.id, it.qty - 1)}
                                    aria-label="Decrease quantity"
                                  >
                                    <Minus className="h-4 w-4" />
                                  </button>
                                  <div className="min-w-8 text-center text-sm text-white/80">{it.qty}</div>
                                  <button
                                    className="grid h-9 w-9 place-items-center rounded-xl text-white/80 hover:bg-white/[0.06]"
                                    onClick={() => cart.setQty(it.id, it.qty + 1)}
                                    aria-label="Increase quantity"
                                  >
                                    <Plus className="h-4 w-4" />
                                  </button>
                                </div>

                                <button
                                  className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.03] text-white/70 hover:bg-white/[0.07]"
                                  onClick={() => cart.remove(it.id)}
                                  aria-label="Remove item"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>

                            <div className="text-right">
                              <div className="text-sm font-semibold text-[#d6b25e]">
                                {formatINR(it.unitPrice * it.qty)}
                              </div>
                            </div>
                          </div>
                        </GlassCard>
                      ))}
                    </div>
                  )}
                </div>

                <div className="border-t border-white/10 p-5">
                  <div className="flex items-center justify-between text-sm">
                    <div className="text-white/60">Subtotal</div>
                    <div className="font-semibold text-white">{formatINR(cart.subtotal)}</div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <button
                      className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white/80 hover:bg-white/[0.07]"
                      onClick={cart.clear}
                      disabled={!canCheckout}
                    >
                      Clear
                    </button>
                    <button
                      className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-[#fff0c2] via-[#d6b25e] to-[#8d6f2b] px-4 py-3 text-sm font-semibold text-black shadow-[0_18px_60px_-22px_rgba(214,178,94,0.65)] disabled:opacity-60"
                      onClick={() => setDetailsOpen(true)}
                      disabled={!canCheckout}
                    >
                      <MessageCircleMore className="h-4 w-4" />
                      Send on WhatsApp
                    </button>
                  </div>
                  <div className="mt-3 text-xs text-white/45">
                    No payment online. Confirm your order via WhatsApp.
                  </div>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <UserDetailsModal
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        brandName={brandName}
        whatsappPhone={whatsappPhone}
      />
    </>
  );
}
