import { AnimatePresence, motion } from 'framer-motion';

export default function AddToCartBurst({
  show,
  x,
  y,
}: {
  show: boolean;
  x: number;
  y: number;
}) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="pointer-events-none fixed z-[90]"
          initial={{ opacity: 0, scale: 0.6, x, y }}
          animate={{ opacity: 1, scale: 1.05, x, y }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.18 }}
        >
          <motion.div
            className="h-3.5 w-3.5 rounded-full bg-[#d6b25e] shadow-[0_10px_30px_rgba(214,178,94,0.55)]"
            animate={{ y: -18 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
