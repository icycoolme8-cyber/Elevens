import { motion, AnimatePresence } from 'framer-motion';

export default function LoadingScreen({ show }: { show: boolean }) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[100] grid place-items-center bg-black"
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="relative w-full max-w-md px-8">
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="mx-auto mb-4 h-12 w-12 rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-xl" />
              <div className="text-2xl tracking-[0.28em] text-white/90">ELEVENS</div>
              <div className="mt-2 text-sm text-white/50">Elevate Your Taste</div>
            </motion.div>

            <div className="mt-10">
              <div className="h-[2px] w-full overflow-hidden rounded bg-white/10">
                <motion.div
                  className="h-full w-1/3 rounded bg-gradient-to-r from-[#6b5b2a] via-[#d6b25e] to-[#fff0c2]"
                  initial={{ x: '-120%' }}
                  animate={{ x: '320%' }}
                  transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
                />
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
