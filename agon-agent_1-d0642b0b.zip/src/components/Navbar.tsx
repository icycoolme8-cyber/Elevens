import { Link, NavLink, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Phone, ShoppingBag, UtensilsCrossed } from 'lucide-react';
import { useCart } from '../lib/cart';

function cls(active: boolean) {
  return active
    ? 'text-white'
    : 'text-white/70 hover:text-white transition-colors';
}

export default function Navbar({ brand = 'Elevens' }: { brand?: string }) {
  const { pathname } = useLocation();
  const cart = useCart();

  return (
    <div className="fixed inset-x-0 top-0 z-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-3">
        <div className="rounded-3xl border border-white/10 bg-black/40 backdrop-blur-2xl shadow-[0_30px_120px_-70px_rgba(0,0,0,0.95)]">
          <div className="flex items-center justify-between px-4 py-3 sm:px-5">
            <Link to="/" className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04]">
                <UtensilsCrossed className="h-5 w-5 text-[#d6b25e]" />
              </div>
              <div>
                <div className="text-sm tracking-[0.32em] text-white/80">{brand.toUpperCase()}</div>
                <div className="text-xs text-white/50 -mt-0.5">Elevate Your Taste</div>
              </div>
            </Link>

            <div className="hidden sm:flex items-center gap-6 text-sm">
              <NavLink to="/" className={({ isActive }) => cls(isActive)} end>
                Home
              </NavLink>
              <NavLink to="/menu" className={({ isActive }) => cls(isActive)}>
                Menu
              </NavLink>
              <a
                className={cls(pathname === '/contact')}
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Contact
              </a>
            </div>

            <div className="flex items-center gap-2">
              <a
                className="hidden sm:inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white/80 hover:bg-white/[0.07] transition"
                href="tel:+919999999999"
              >
                <Phone className="h-4 w-4 text-[#d6b25e]" />
                Call
              </a>

              <motion.button
                onClick={cart.toggleCart}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="relative inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white/90 hover:bg-white/[0.07] transition"
                aria-label="Open cart"
              >
                <ShoppingBag className="h-4 w-4 text-[#d6b25e]" />
                <span className="hidden sm:inline">Cart</span>
                {cart.totalQty > 0 && (
                  <span className="ml-0.5 inline-flex h-6 min-w-6 items-center justify-center rounded-full bg-[#d6b25e] px-2 text-xs font-semibold text-black">
                    {cart.totalQty}
                  </span>
                )}
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
