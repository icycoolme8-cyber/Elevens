import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, MapPin, Phone, User, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useCart } from '../lib/cart';
import GlassCard from './GlassCard';
import { buildWhatsAppMessage, openWhatsApp } from '../lib/whatsapp';

export default function UserDetailsModal({
  open,
  onClose,
  brandName,
  whatsappPhone,
}: {
  open: boolean;
  onClose: () => void;
  brandName: string;
  whatsappPhone: string;
}) {
  const cart = useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  const canSend = useMemo(() => cart.items.length > 0 && name.trim().length >= 2 && phone.trim().length >= 8, [cart.items.length, name, phone]);

  const send = () => {
    const message = buildWhatsAppMessage({
      brandName,
      items: cart.items.map((it) => ({ name: it.name, qty: it.qty, unitPrice: it.unitPrice })),
      customer: { name: name.trim(), phone: phone.trim(), address: address.trim() },
    });
    openWhatsApp(whatsappPhone, message);
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[90] bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed inset-0 z-[95] grid place-items-center p-4"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.22 }}
          >
            <GlassCard className="w-full max-w-lg overflow-hidden">
              <div className="flex items-start justify-between border-b border-white/10 p-5">
                <div>
                  <div className="text-lg font-semibold text-white">Customer Details</div>
                  <div className="mt-1 text-sm text-white/55">
                    We’ll format your order and open WhatsApp.
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
                  aria-label="Close"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <label className="block">
                  <div className="mb-2 text-xs tracking-wide text-white/60">Name</div>
                  <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-3">
                    <User className="h-4 w-4 text-[#d6b25e]" />
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-transparent text-sm text-white/90 placeholder:text-white/30 outline-none"
                      placeholder="Your name"
                    />
                  </div>
                </label>

                <label className="block">
                  <div className="mb-2 text-xs tracking-wide text-white/60">Phone</div>
                  <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-3">
                    <Phone className="h-4 w-4 text-[#d6b25e]" />
                    <input
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-transparent text-sm text-white/90 placeholder:text-white/30 outline-none"
                      placeholder="e.g. 9876543210"
                      inputMode="tel"
                    />
                  </div>
                </label>

                <label className="block">
                  <div className="mb-2 text-xs tracking-wide text-white/60">Address</div>
                  <div className="flex items-start gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-3">
                    <MapPin className="mt-0.5 h-4 w-4 text-[#d6b25e]" />
                    <textarea
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="min-h-24 w-full resize-none bg-transparent text-sm text-white/90 placeholder:text-white/30 outline-none"
                      placeholder="House / Street / Landmark"
                    />
                  </div>
                </label>

                <div className="pt-2 grid grid-cols-2 gap-3">
                  <button
                    className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white/80 hover:bg-white/[0.07]"
                    onClick={onClose}
                  >
                    Cancel
                  </button>
                  <button
                    className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-[#fff0c2] via-[#d6b25e] to-[#8d6f2b] px-4 py-3 text-sm font-semibold text-black shadow-[0_18px_60px_-22px_rgba(214,178,94,0.65)] disabled:opacity-60"
                    onClick={send}
                    disabled={!canSend}
                  >
                    Continue
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>

                <div className="text-xs text-white/45">
                  Tip: WhatsApp number can be updated in settings.
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
