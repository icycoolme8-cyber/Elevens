import { motion } from 'framer-motion';
import React from 'react';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'gold' | 'ghost';
  size?: 'md' | 'lg';
};

export default function GoldButton({
  variant = 'gold',
  size = 'md',
  className = '',
  children,
  ...props
}: Props) {
  const base =
    'relative inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-medium tracking-wide transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d6b25e]/70 focus-visible:ring-offset-0 disabled:opacity-60 disabled:cursor-not-allowed';
  const sizes = size === 'lg' ? 'px-6 py-3.5 text-base' : '';

  const styles =
    variant === 'gold'
      ? 'text-black bg-gradient-to-b from-[#fff0c2] via-[#d6b25e] to-[#8d6f2b] shadow-[0_18px_60px_-22px_rgba(214,178,94,0.65)]'
      : 'text-white/90 border border-white/15 bg-white/[0.04] backdrop-blur-xl hover:bg-white/[0.07]';

  return (
    <motion.button
      {...(props as any)}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={`${base} ${sizes} ${styles} ${className}`}
    >
      <span className="absolute inset-0 rounded-2xl opacity-0 transition-opacity group-hover:opacity-100" />
      {children}
    </motion.button>
  );
}
