import React from 'react';

export default function GlassCard({
  className = '',
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className={`rounded-3xl border border-white/10 bg-white/[0.04] backdrop-blur-2xl shadow-[0_20px_80px_-45px_rgba(0,0,0,0.8)] ${className}`}
    >
      {children}
    </div>
  );
}
