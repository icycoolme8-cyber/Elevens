import { motion } from 'framer-motion';
import type { Category } from '../lib/api';

export default function MenuTabs({
  categories,
  activeId,
  onChange,
}: {
  categories: Category[];
  activeId: number | null;
  onChange: (id: number) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [-ms-overflow-style:none]">
      <style>{`.hide-scroll::-webkit-scrollbar{display:none;}`}</style>
      <div className="hide-scroll flex gap-2">
        {categories.map((c) => {
          const active = c.id === activeId;
          return (
            <button
              key={c.id}
              onClick={() => onChange(c.id)}
              className="relative rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white/80 hover:bg-white/[0.07] transition"
            >
              {active && (
                <motion.span
                  layoutId="tab"
                  className="absolute inset-0 rounded-2xl bg-gradient-to-b from-[#fff0c2]/25 via-[#d6b25e]/15 to-transparent"
                  transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                />
              )}
              <span className="relative">{c.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
