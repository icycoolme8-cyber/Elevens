import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { MenuItem } from '../lib/api';
import { formatINR } from '../lib/format';
import GlassCard from './GlassCard';

export default function FeaturedCarousel({ items }: { items: MenuItem[] }) {
  const featured = useMemo(() => items.filter((i) => i.is_featured).slice(0, 8), [items]);
  const [idx, setIdx] = useState(0);

  const current = featured.length ? featured[idx % featured.length] : null;

  return (
    <div>
      <div className="flex items-end justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-white/70">
            <Sparkles className="h-4 w-4 text-[#d6b25e]" />
            Featured
          </div>
          <h3 className="mt-3 text-2xl sm:text-3xl font-semibold text-white">Chef’s Spotlight</h3>
          <p className="mt-2 max-w-xl text-sm text-white/60">
            A rotating selection of signature plates crafted for late-night cravings and luxury comfort.
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-2">
          <button
            className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
            onClick={() => setIdx((v) => (v - 1 + featured.length) % featured.length)}
            aria-label="Previous"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
            onClick={() => setIdx((v) => (v + 1) % featured.length)}
            aria-label="Next"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="mt-6">
        {!current ? (
          <GlassCard className="p-6">
            <div className="text-white/60">No featured dishes yet.</div>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <GlassCard className="overflow-hidden">
              <div className="relative aspect-[16/11]">
                <img
                  src={current.image_url}
                  alt={current.name}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                <div className="absolute left-5 bottom-5 right-5">
                  <div className="text-xl font-semibold text-white">{current.name}</div>
                  <div className="mt-1 text-sm text-white/60 line-clamp-2">{current.description}</div>
                </div>
              </div>
            </GlassCard>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {featured.slice(0, 4).map((it, i) => (
                <motion.div
                  key={it.id}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 0.5, delay: i * 0.05 }}
                >
                  <GlassCard className="overflow-hidden h-full">
                    <div className="relative aspect-[16/11]">
                      <img
                        src={it.image_url}
                        alt={it.name}
                        loading="lazy"
                        className="absolute inset-0 h-full w-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                      <div className="absolute left-4 bottom-4 right-4">
                        <div className="text-sm font-semibold text-white">{it.name}</div>
                        <div className="mt-1 text-xs text-white/60 line-clamp-2">{it.description}</div>
                        <div className="mt-2 text-xs text-[#d6b25e]">{formatINR(it.price)}</div>
                      </div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}

              <div className="sm:hidden flex items-center gap-2">
                <button
                  className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
                  onClick={() => setIdx((v) => (v - 1 + featured.length) % featured.length)}
                  aria-label="Previous"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  className="grid h-10 w-10 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.07]"
                  onClick={() => setIdx((v) => (v + 1) % featured.length)}
                  aria-label="Next"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
